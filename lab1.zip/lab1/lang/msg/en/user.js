export const msg = {
  wHead: "Note writer",
  wPlacehold: "Write something...",
  wAddNote: "Add note",
  back: "Back",
  wLastSaved: "Last saved: ",
  wLastSavedNotYet: "Last saved: Not yet",
  wDel: "Delete",
  rHead: "Note reader",
  mHead: "Lab 1: JSON, Object Constructor, localStorage Clement Quach",
  head: "Lab 1: JSON, Object Constructor, localStorage Clement Quach",
  writer: "Writer",
  reader: "Reader",

}
