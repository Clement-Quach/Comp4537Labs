export const msg = {
  go: "go",
  prompt: "how many buttons to create?",
  win: "you win",
  lose: "you lose"
}
